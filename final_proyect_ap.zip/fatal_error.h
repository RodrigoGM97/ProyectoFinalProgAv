//Advanced Programming Final Project
//Chat
//
//10-05-19
//
//Rodrigo Garcia
//A01024595
//
//Saul Labra
//A01020725

#ifndef FATAL_ERROR_H
#define FATAL_ERROR_H

#include <stdio.h>
#include <stdlib.h>

void fatalError(const char * message);

#endif  /* NOT FATAL_ERROR_H */
